import random
import tkinter as tk
import time
import winsound
from tkinter import PhotoImage

def play_game(player_choice):
    player_label.config(text=f"Твой выбор: {player_choice.capitalize()}", fg="#001869")
    
    computer_label.config(text="Компьютер выбирает...", fg="#ff0000")
    
    root.after(1000, animate_computer_choice, player_choice)

def animate_computer_choice(player_choice):
    PC = ["Камень", "Ножницы", "Бумага"]
    
    choices = random.choices(PC, k=20)  
    for i in range(20):
        computer_label.config(text=f"Компьютер выбрал: {choices[i].capitalize()}", fg="#ff0000")
        root.update()  
        time.sleep(0.1)  
    
    computer_choice = random.choice(PC)
    computer_label.config(text=f"Компьютер выбрал: {computer_choice.capitalize()}", fg="#7c0000")
    
    result = determine_winner(player_choice, computer_choice)
    
    result_label.config(text=f"Результат: {result}", fg="#d3d3d3", font=("Helvetica", 16, "bold"))
    
    button_rock.config(state=tk.NORMAL)
    button_scissors.config(state=tk.NORMAL)
    button_paper.config(state=tk.NORMAL)

def determine_winner(player_choice, computer_choice):
    if (computer_choice == "Камень" and player_choice == "Ножницы") or \
       (computer_choice == "Ножницы" and player_choice == "Бумага") or \
       (computer_choice == "Бумага" and player_choice == "Камень"):
        return "Ты проиграл!"
    elif (computer_choice == "Камень" and player_choice == "Бумага") or \
         (computer_choice == "Ножницы" and player_choice == "Камень") or \
         (computer_choice == "Бумага" and player_choice == "Ножницы"):
        return "Ты победил!"
    else:
        return "Ничья!"

def play_sound():
    winsound.Beep(500, 200)  # Звук 500 Гц длительностью 200 мс

root = tk.Tk()
root.title("Камень, Ножницы, Бумага")
root.geometry("300x650")
root.resizable(False, False)
root.config(bg="#404040")

# Загрузка изображений и изменение их размера
rock_img = PhotoImage(file="images/rock.png").subsample(3, 3)  # уменьшение изображения в 3 раза
scissors_img = PhotoImage(file="images/scissors.png").subsample(3, 3)  # уменьшение изображения в 3 раза
paper_img = PhotoImage(file="images/paper.png").subsample(3, 3)  # уменьшение изображения в 3 раза

# Создание кнопок с иконками
button_rock = tk.Button(root, image=rock_img, width=100, height=100, bg="#717171", command=lambda: [play_game("Камень"), play_sound()])
button_rock.pack(pady=10)

button_scissors = tk.Button(root, image=scissors_img, width=100, height=100, bg="#717171", command=lambda: [play_game("Ножницы"), play_sound()])
button_scissors.pack(pady=10)

button_paper = tk.Button(root, image=paper_img, width=100, height=100, bg="#717171", command=lambda: [play_game("Бумага"), play_sound()])
button_paper.pack(pady=10)

player_label = tk.Label(root, text="Твой выбор: ", font=("Helvetica", 14), bg="#404040")
player_label.pack(pady=20)

computer_label = tk.Label(root, text="Компьютер выбирает...", font=("Helvetica", 14), bg="#404040")
computer_label.pack(pady=20)

result_label = tk.Label(root, text="Результат: ", font=("Helvetica", 16), bg="#404040")
result_label.pack(pady=20)

root.mainloop()
